"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import BeadCanvas from "./BeadCanvas";
import RightOptionsPanel from "./rightOptionsPanel";

export type Bead = {
  id: string;
  socketIndex: number;
  size: number;
  color: string;
  name?: string;
  image?: string;
  angle: number;
  entryAngle?: number;
  exitAngle?: number;
  location?: "bracelet" | "waiting";
};

export default function Page() {
  const router = useRouter();
  const [beads, setBeads] = useState<Bead[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // ✅ Check login session on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      router.push("/login");
    } else {
      setIsLoading(false);
    }
  }, [router]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen text-gray-600">
        Checking session...
      </div>
    );
  }

  // ✅ If logged in, show the actual bead editor
  return (
    <DndProvider backend={HTML5Backend}>
      <main className="flex justify-center items-center w-screen h-screen">
        <div className="flex w-full h-full">
          {/* Left: Bead Canvas (50%) */}
          <div className="w-1/2 h-full shrink-0">
            <BeadCanvas beads={beads} setBeads={setBeads} />
          </div>

          {/* Right: Options Panel (50%) */}
          <div className="w-1/2 h-full shrink-0">
            <RightOptionsPanel
              setPlacedBeads={setBeads}
              onFooter={(action) => {
                if (action.type === "clear_canvas") {
                  setBeads([]); // clears the canvas
                }
              }}
            />
          </div>
        </div>
      </main>
    </DndProvider>
  );
}
