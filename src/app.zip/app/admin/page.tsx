"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";

type Bead = {
  id: number;
  name: string;
  category: string;
  subgroup: string;
  size: string[];
  price: number;
  image: string;
  shape: string;
  color: string;
  aspirations: string[];
  astrology: string[];
};

export default function AdminPage() {
  const router = useRouter();
  const [user, setUser] = useState<{ name: string; role: string } | null>(null);
  const [beads, setBeads] = useState<Bead[]>([]);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState("");

  // ✅ Form state
  const [form, setForm] = useState<Partial<Bead>>({
    size: [],
    aspirations: [],
    astrology: [],
  });

  const [editing, setEditing] = useState<number | null>(null);

  // ✅ Dropdown lists
  const [lists, setLists] = useState({
    categories: ["Crystals & Mineraloids"],
    subgroups: ["Silicate Crystals", "Mineraloids", "Phosphate & Other Crystals"],
    shapes: ["Spherical"],
    aspirations: [
      "Health",
      "Protection",
      "Luck",
      "Inner Peace",
      "Creativity",
      "Wisdom",
      "Career",
      "Growth",
    ],
    astrology: [
      "Virgo",
      "Taurus",
      "Leo",
      "Scorpio",
      "Sagittarius",
      "Libra",
      "Capricorn",
      "Aries",
    ],
  });

  // ✅ Check login
  useEffect(() => {
    const stored = localStorage.getItem("user");
    if (!stored) return router.push("/login");
    const parsed = JSON.parse(stored);
    if (parsed.role !== "admin") return router.push("/config");
    setUser(parsed);
  }, [router]);

  // ✅ Fetch beads
  async function loadBeads() {
    try {
      const res = await fetch("https://mypoesis.ruputech.com/api/getBeads.php");
      const data = await res.json();
      if (data.success) {
        const mapped = data.beads.map((b: any) => ({
          ...b,
          category: b.material.category,
          subgroup: b.material.subgroup,
        }));
        setBeads(mapped);
      }
    } catch (err) {
      console.error("Fetch error:", err);
    }
  }

  useEffect(() => {
    loadBeads();
  }, []);

  // ✅ Upload image
  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch("https://mypoesis.ruputech.com/api/upload.php", {
      method: "POST",
      body: formData,
    });
    const data = await res.json();
    if (data.success) {
      setForm((f) => ({ ...f, image: data.path }));
      setPreview(data.path);
    } else setMessage("Image upload failed.");
  }

  // ✅ Add tag
  function handleTagInput(
    e: React.KeyboardEvent<HTMLInputElement>,
    field: "size" | "aspirations" | "astrology"
  ) {
    if (e.key === " " && e.currentTarget.value.trim() !== "") {
      e.preventDefault();
      const value = e.currentTarget.value.trim();
      setForm((prev) => ({
        ...prev,
        [field]: [...(prev[field] || []), value],
      }));
      e.currentTarget.value = "";
    }
  }

  // ✅ Remove tag
  const removeTag = (field: "size" | "aspirations" | "astrology", value: string) => {
    setForm((prev) => ({
      ...prev,
      [field]: (prev[field] || []).filter((v) => v !== value),
    }));
  };

      // ✅ Add or update bead
      const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!form.name) return setMessage("Please fill all required fields.");

      const endpoint = editing
      ? "https://mypoesis.ruputech.com/api/updateBead.php"
      : "https://mypoesis.ruputech.com/api/addBead.php";

      const payload = { ...form };
      if (editing) payload.id = editing;

      const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      });

      const data = await res.json();
      setMessage(data.message);

      if (data.success) {
      await loadBeads();
      setForm({ size: [], aspirations: [], astrology: [] });
      setPreview(null);
      setEditing(null);
      }
      };

  // ✅ Soft delete
  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to deactivate this bead?")) return;
    const res = await fetch("https://mypoesis.ruputech.com/api/deleteBead.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    const data = await res.json();
    setMessage(data.message);
    if (data.success) {
      setBeads((prev) => prev.filter((b) => b.id !== id));
    }
  };

  // ✅ Edit bead
  const handleEdit = (bead: Bead) => {
    setEditing(bead.id);
    setForm(bead);
    setPreview(bead.image);
  };

  if (!user) return null;

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ backgroundColor: "#F7EEE7", fontFamily: "Poppins, sans-serif" }}
    >
      {/* Header */}
      <div className="flex justify-between items-center px-8 py-6 bg-[#EB9385] text-white">
        <h1 className="text-2xl font-semibold">Beads Admin Dashboard</h1>
        <div className="flex gap-4 items-center">
          <span>{user.name}</span>
          <button
            onClick={() => {
              localStorage.removeItem("user");
              router.push("/login");
            }}
            className="bg-white text-[#C04365] px-4 py-1 rounded-full text-sm hover:bg-[#fde4e4]"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col lg:flex-row flex-1 p-8 gap-8">
        {/* Form Section */}
        <form
          onSubmit={handleSubmit}
          className="bg-white/80 rounded-xl shadow-md p-6 w-full lg:w-[420px] overflow-auto"
        >
          <h2 className="text-lg font-semibold mb-4 text-[#C04365]">
            {editing ? "Edit Bead" : "Add New Bead"}
          </h2>

          {/* Fields */}
          <input
            type="text"
            placeholder="Bead name"
            value={form.name || ""}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="border p-2 rounded-md w-full mb-3 outline-none"
            style={{ borderColor: "#EB9385" }}
          />

          <DropdownField
            label="Category"
            value={form.category}
            onChange={(v) => setForm({ ...form, category: v })}
            options={lists.categories}
          />
          <DropdownField
            label="Subgroup"
            value={form.subgroup}
            onChange={(v) => setForm({ ...form, subgroup: v })}
            options={lists.subgroups}
          />
          <DropdownField
            label="Shape"
            value={form.shape}
            onChange={(v) => setForm({ ...form, shape: v })}
            options={lists.shapes}
          />

          <input
            type="text"
            placeholder="Color"
            value={form.color || ""}
            onChange={(e) => setForm({ ...form, color: e.target.value })}
            className="border p-2 rounded-md w-full mb-3 outline-none"
            style={{ borderColor: "#EB9385" }}
          />

          <input
            type="number"
            placeholder="Price"
            step="0.01"
            value={form.price || ""}
            onChange={(e) => setForm({ ...form, price: parseFloat(e.target.value) })}
            className="border p-2 rounded-md w-full mb-3 outline-none"
            style={{ borderColor: "#EB9385" }}
          />

          {/* Tags */}
          <TagField label="Size" field="size" tags={form.size || []} removeTag={removeTag} handleTagInput={handleTagInput} />
          <TagField label="Aspirations" field="aspirations" tags={form.aspirations || []} removeTag={removeTag} handleTagInput={handleTagInput} />
          <TagField label="Astrology" field="astrology" tags={form.astrology || []} removeTag={removeTag} handleTagInput={handleTagInput} />

          {/* Image */}
          <div className="mt-3">
            <label className="text-sm text-gray-700 font-medium">Image</label>
            <input type="file" ref={fileInputRef} accept="image/*" onChange={handleImageUpload} className="block w-full text-sm mt-1" />
            {preview && (
              <div className="mt-2">
                <Image src={preview} alt="preview" width={100} height={100} className="rounded-md border" />
              </div>
            )}
          </div>

          <button
            type="submit"
            className="mt-5 w-full py-2 rounded-full text-white font-semibold hover:scale-[1.02] transition"
            style={{ backgroundColor: "#C04365" }}
          >
            {editing ? "Update Bead" : "Save Bead"}
          </button>
          {message && <p className="text-[#C04365] text-sm mt-2">{message}</p>}
        </form>

        {/* Beads Preview */}
        <div className="flex-1 bg-white/80 rounded-xl shadow-md p-6 overflow-auto">
          <h2 className="text-lg font-semibold mb-4 text-[#C04365]">Bead Inventory</h2>
          {beads.length === 0 ? (
            <p>No beads yet.</p>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {beads.map((b) => (
                <div
                  key={b.id}
                  className="flex flex-col sm:flex-row justify-between items-start sm:items-center border border-[#EB9385]/30 rounded-xl p-4 bg-[#fffaf8]"
                  >
                  {/* Left Info */}
                  <div className="flex flex-col sm:flex-row gap-4">
                  <div className="relative w-24 h-24 aspect-square overflow-hidden rounded-md border border-[#EB9385]/40 bg-white">
                        <Image
                        src={b.image || "/placeholder.jpg"}
                        alt={b.name}
                        fill
                        className="object-cover"
                        />
                  </div>
                  <div>
                        <p className="font-semibold text-[#C04365]">{b.name}</p>
                        <p className="text-sm text-gray-600">
                        {b.category} — {b.subgroup}
                        </p>
                        <p className="text-sm">Color: {b.color}</p>
                        <p className="text-sm">Shape: {b.shape}</p>
                        <p className="text-sm">Price: RM {b.price.toFixed(2)}</p>
                        <p className="text-sm">
                        Size: {b.size?.join(", ") || "—"}
                        </p>
                        <p className="text-sm">
                        Astrology: {b.astrology?.join(", ") || "—"}
                        </p>
                  </div>
                  </div>

                  {/* Right Buttons */}
                  <div className="flex gap-3 mt-3 sm:mt-0">
                  <button onClick={() => handleEdit(b)} title="Edit">
                        <Image src="/icons/filter.svg" width={22} height={22} alt="edit" />
                  </button>
                  <button onClick={() => handleDelete(b.id)} title="Delete">
                        <Image src="/icons/delete.svg" width={22} height={22} alt="delete" />
                  </button>
                  </div>
                  </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// 🔸 Reusable Dropdown
function DropdownField({ label, value, onChange, options }: any) {
  const [search, setSearch] = useState("");
  const [list, setList] = useState(options);
  const [open, setOpen] = useState(false);

  function handleAddOther() {
    if (!search) return;
    setList((prev) => [...prev, search]);
    onChange(search);
    setSearch("");
    setOpen(false);
  }

  return (
    <div className="mb-3 relative">
      <label className="text-sm text-gray-700 font-medium">{label}</label>
      <div
        className="border p-2 rounded-md w-full text-sm bg-white cursor-pointer select-none"
        style={{ borderColor: "#EB9385" }}
        onClick={() => setOpen((o) => !o)}
      >
        {value || `Select ${label.toLowerCase()}`}
      </div>
      {open && (
        <div className="absolute z-20 bg-white shadow-md rounded-md mt-1 w-full max-h-40 overflow-y-auto border border-[#EB9385]">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search..."
            className="w-full px-2 py-1 border-b text-sm outline-none"
          />
          {list
            .filter((v: string) => v.toLowerCase().includes(search.toLowerCase()))
            .map((opt: string) => (
              <div
                key={opt}
                className="px-2 py-1 hover:bg-[#fdf4f2] cursor-pointer"
                onClick={() => {
                  onChange(opt);
                  setOpen(false);
                }}
              >
                {opt}
              </div>
            ))}
          {search && !list.includes(search) && (
            <div
              className="px-2 py-1 text-[#C04365] hover:bg-[#fde4e4] cursor-pointer"
              onClick={handleAddOther}
            >
              ➕ Add “{search}”
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// 🔸 Reusable Tag Field
function TagField({ label, field, tags, removeTag, handleTagInput }: any) {
  return (
    <div className="mb-3">
      <label className="text-sm text-gray-700 font-medium">{label}</label>
      <div
        className="border rounded-md flex flex-wrap gap-2 p-2"
        style={{ borderColor: "#EB9385" }}
      >
        {tags.map((tag: string) => (
          <div
            key={tag}
            className="flex items-center gap-1 bg-[#EB9385]/20 px-2 py-1 rounded-full text-sm"
          >
            <span>{tag}</span>
            <button
              type="button"
              onClick={() => removeTag(field, tag)}
              className="text-[#C04365] hover:text-red-500"
            >
              ×
            </button>
          </div>
        ))}
        <input
          onKeyDown={(e) => handleTagInput(e, field)}
          placeholder={`Add ${label.toLowerCase()} (space to add)`}
          className="flex-1 min-w-[100px] text-sm outline-none bg-transparent"
        />
      </div>
    </div>
  );
}
